# Daily Wins — {{YYYY-MM-DD}}

## Quick Check (tick what you did)
- [ ] GATE: 2 hrs OR 20 MCQs reviewed
- [ ] DSA/Code: 2 problems OR 45 min dev work
- [ ] Placement Prep: 30 min (aptitude/comm/HR)
- [ ] Revision: 30 min spaced review
- [ ] Fitness: workout OR ≥8k steps
- [ ] Mind: 10 min meditation/journaling
- [ ] Sleep target: ≥7h (before 12 AM)

## Notes (1–3 bullet points max)
- 

## Today’s Top 1–3 Wins (short & crisp)
1. 
2. 
3. 

## Proof / Attachments (optional)
- Image(s): `assets/YYYY-MM/<your-file>.png`  
- Paste relative links here: `![alt](../../assets/2025-08/screenshot-01.png)`

## Stats (optional)
- Study hours: 
- Mood (1–5): 
