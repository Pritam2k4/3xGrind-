# 🗓️ Daily Wins (Preetam • Manas • Abhiram)

Simple, checkbox-based daily logs on GitHub. One folder per person → year → month → day.

## Quick Start
1) Go to **your folder** > **year** > **month**.
2) Click **Add file → Create new file**.
3) Name it `YYYY-MM-DD.md` (e.g., `2025-08-13.md`).
4) Open `daily-template.md`, copy all, paste into your new file.
5) Tick checkboxes, add 1–3 wins, and **Commit directly to main**.

## Images (optional)
- Click **Add file → Upload files**, drop images into `assets/YYYY-MM/`.
- In your log, reference them like:
  ```
  ![alt text](../../assets/2025-08/proof-01.png)
  ```

## Folders
- [`preetam/`](./preetam) • [`manas/`](./manas) • [`abhiram/`](./abhiram)

## Tips
- Keep it short. Check boxes, jot wins, attach one proof if you want.
- Logging should take **< 3 minutes**.
